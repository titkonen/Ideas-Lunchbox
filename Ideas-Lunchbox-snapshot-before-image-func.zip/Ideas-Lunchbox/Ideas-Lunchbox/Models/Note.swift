import Foundation

/// Single note

//struct Note {
//    var title: String
//    var date: Date
//    var text: String
//}

