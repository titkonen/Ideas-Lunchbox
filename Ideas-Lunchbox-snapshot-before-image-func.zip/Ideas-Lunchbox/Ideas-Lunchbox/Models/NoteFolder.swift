import Foundation

//struct NoteFolder  {
//    var title: String
//    var notes: [Note]
//}
